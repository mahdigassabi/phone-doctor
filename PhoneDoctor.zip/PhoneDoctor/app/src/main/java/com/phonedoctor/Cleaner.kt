package com.phonedoctor

import android.content.Context
import android.text.format.Formatter
import java.io.File

/**
 * Safe cleaner with restore points.
 *
 * Nothing is deleted directly. Files are MOVED into a restore point folder
 * (with a manifest of original locations), so the last clean can be undone.
 * Space is only really freed when the user empties the restore points.
 *
 * Android sandboxing means this can only touch this app's own cache folders.
 */
object Cleaner {

    private const val MANIFEST = "manifest.txt"

    private fun root(ctx: Context): File = File(ctx.filesDir, "restore_points").apply { mkdirs() }

    private fun sizeOf(f: File): Long =
        if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun move(src: File, dst: File): Boolean {
        if (src.renameTo(dst)) return true
        return try {
            if (src.copyRecursively(dst, overwrite = false)) {
                src.deleteRecursively()
                true
            } else {
                dst.deleteRecursively()
                false
            }
        } catch (e: Exception) {
            dst.deleteRecursively()
            false
        }
    }

    private fun latestPoint(ctx: Context): File? =
        root(ctx).listFiles { f -> f.isDirectory }?.maxByOrNull { it.name.toLongOrNull() ?: 0L }

    fun cleanSafely(ctx: Context): String {
        val items = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
            .flatMap { (it.listFiles() ?: emptyArray()).toList() }
        if (items.isEmpty()) return "چیزی برای پاکسازی پیدا نشد (حافظه موقت اپ خالی است)."

        val point = File(root(ctx), System.currentTimeMillis().toString()).apply { mkdirs() }
        val manifest = StringBuilder()
        var bytes = 0L
        var moved = 0
        items.forEachIndexed { idx, f ->
            val size = sizeOf(f)
            if (move(f, File(point, idx.toString()))) {
                manifest.append("$idx\t${f.absolutePath}\n")
                bytes += size
                moved++
            }
        }
        File(point, MANIFEST).writeText(manifest.toString())
        return "✅ $moved مورد (${Formatter.formatFileSize(ctx, bytes)}) به نقطه بازیابی منتقل شد.\n" +
            "اگر مشکلی پیش آمد «بازگردانی آخرین پاکسازی» را بزنید."
    }

    fun restoreLast(ctx: Context): String {
        val point = latestPoint(ctx) ?: return "نقطه بازیابی‌ای وجود ندارد."
        val manifest = File(point, MANIFEST)
        if (!manifest.exists()) {
            point.deleteRecursively()
            return "نقطه بازیابی ناقص بود و حذف شد."
        }
        var restored = 0
        var skipped = 0
        manifest.readLines().filter { it.isNotBlank() }.forEach { line ->
            val parts = line.split("\t", limit = 2)
            if (parts.size < 2) return@forEach
            val src = File(point, parts[0])
            val dst = File(parts[1])
            if (!src.exists() || dst.exists()) {
                skipped++
                return@forEach
            }
            dst.parentFile?.mkdirs()
            if (move(src, dst)) restored++ else skipped++
        }
        point.deleteRecursively()
        return "↩️ $restored مورد به حالت قبل برگشت" + if (skipped > 0) " ($skipped مورد رد شد)." else "."
    }

    fun emptyRestorePoints(ctx: Context): String {
        val r = root(ctx)
        val bytes = sizeOf(r)
        r.deleteRecursively()
        r.mkdirs()
        return "🗑️ نقاط بازیابی پاک شد؛ ${Formatter.formatFileSize(ctx, bytes)} آزاد شد. (دیگر امکان بازگردانی نیست.)"
    }
}
