package com.phonedoctor

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var output: TextView
    private var lastReport: String = ""

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(16.dp(), 24.dp(), 16.dp(), 24.dp())
        }

        val title = TextView(this).apply {
            text = "پزشک گوشی"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
        }

        output = TextView(this).apply {
            text = "برای شروع «اسکن کامل» را بزنید."
            textSize = 15f
            setPadding(0, 12.dp(), 0, 16.dp())
            setTextIsSelectable(true)
        }

        root.addView(title)
        root.addView(output)

        root.addView(section("بررسی"))
        root.addView(button("🔍 اسکن کامل") { scan() })
        root.addView(button("📤 اشتراک‌گذاری گزارش") { shareReport() })

        root.addView(section("پاکسازی امن (با امکان برگشت)"))
        root.addView(button("🧹 پاکسازی امن") { background { Cleaner.cleanSafely(this) } })
        root.addView(button("↩️ بازگردانی آخرین پاکسازی") { background { Cleaner.restoreLast(this) } })
        root.addView(button("🗑️ پاک‌کردن نقاط بازیابی") { background { Cleaner.emptyRestorePoints(this) } })

        root.addView(section("میانبر به تنظیمات سیستم (کارهایی که فقط خود اندروید می‌تواند)"))
        root.addView(button("💾 تنظیمات ذخیره‌سازی") { open(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) })
        root.addView(button("🔋 تنظیمات باتری") { open(Settings.ACTION_BATTERY_SAVER_SETTINGS) })
        root.addView(button("📱 مدیریت برنامه‌ها") { open(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS) })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 20.dp(), 0, 6.dp())
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun scan() {
        output.text = "در حال بررسی…"
        Thread {
            val report = try {
                Diagnostics.render(Diagnostics.run(this))
            } catch (e: Exception) {
                "خطا در اسکن: ${e.message}"
            }
            runOnUiThread {
                lastReport = report
                output.text = report
            }
        }.start()
    }

    private fun background(task: () -> String) {
        output.text = "در حال انجام…"
        Thread {
            val result = try {
                task()
            } catch (e: Exception) {
                "خطا: ${e.message}"
            }
            runOnUiThread { output.text = result }
        }.start()
    }

    private fun shareReport() {
        if (lastReport.isBlank()) {
            Toast.makeText(this, "اول اسکن کامل را اجرا کنید", Toast.LENGTH_SHORT).show()
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, lastReport)
        }
        startActivity(Intent.createChooser(send, "ارسال گزارش"))
    }

    private fun open(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "این صفحه روی گوشی شما موجود نیست", Toast.LENGTH_SHORT).show()
        }
    }
}
