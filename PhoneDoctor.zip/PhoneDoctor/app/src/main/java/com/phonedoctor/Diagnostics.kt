package com.phonedoctor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.text.format.Formatter
import java.io.File
import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class Severity { OK, WARN, BAD }

data class Finding(
    val title: String,
    val detail: String,
    val severity: Severity,
    val fix: String? = null
)

object Diagnostics {

    fun run(ctx: Context): List<Finding> {
        val all = mutableListOf<Finding>()
        val checks: List<(Context) -> List<Finding>> = listOf(
            ::battery, ::storage, ::memory, ::thermal, ::cpu, ::security, ::uptime
        )
        for (check in checks) {
            try {
                all += check(ctx)
            } catch (e: Exception) {
                all += Finding("خطا در بررسی", e.javaClass.simpleName + ": " + (e.message ?: ""), Severity.WARN)
            }
        }
        return all
    }

    fun render(list: List<Finding>): String {
        val bad = list.count { it.severity == Severity.BAD }
        val warn = list.count { it.severity == Severity.WARN }
        val sb = StringBuilder()
        sb.append("خلاصه: $bad مشکل جدی، $warn هشدار\n")
        sb.append("مدل: ${Build.MANUFACTURER} ${Build.MODEL} | اندروید ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n")
        for (f in list.sortedByDescending { it.severity.ordinal }) {
            val icon = when (f.severity) {
                Severity.OK -> "✅"
                Severity.WARN -> "⚠️"
                Severity.BAD -> "❌"
            }
            sb.append("$icon ${f.title}: ${f.detail}\n")
            if (f.fix != null) sb.append("   ← ${f.fix}\n")
            sb.append("\n")
        }
        return sb.toString().trimEnd()
    }

    // ---------- Battery ----------
    private fun battery(ctx: Context): List<Finding> {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return listOf(Finding("باتری", "اطلاعات باتری در دسترس نیست", Severity.WARN))
        val out = mutableListOf<Finding>()

        val health = i.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val (txt, sev) = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "سالم" to Severity.OK
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "بیش‌ازحد داغ" to Severity.BAD
            BatteryManager.BATTERY_HEALTH_DEAD -> "خراب" to Severity.BAD
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "ولتاژ بیش‌ازحد" to Severity.BAD
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "خرابی نامشخص" to Severity.BAD
            BatteryManager.BATTERY_HEALTH_COLD -> "بیش‌ازحد سرد" to Severity.WARN
            else -> "نامشخص" to Severity.WARN
        }
        out += Finding(
            "سلامت باتری", txt, sev,
            if (sev == Severity.BAD) "باتری سخت‌افزاری است و با نرم‌افزار تعمیر نمی‌شود؛ به تعمیرکار مراجعه کنید." else null
        )

        val tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        val tSev = when {
            tempC >= 45 -> Severity.BAD
            tempC >= 40 -> Severity.WARN
            else -> Severity.OK
        }
        out += Finding(
            "دمای باتری", "%.1f درجه سانتی‌گراد".format(tempC), tSev,
            if (tSev != Severity.OK) "شارژ را قطع کنید، قاب را بردارید و از نور مستقیم خورشید دور کنید." else null
        )

        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level >= 0) out += Finding("شارژ فعلی", "${level * 100 / scale}%", Severity.OK)

        if (Build.VERSION.SDK_INT >= 34) {
            val cycles = i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)
            if (cycles > 0) {
                val s = if (cycles > 800) Severity.WARN else Severity.OK
                out += Finding(
                    "تعداد چرخه شارژ", "$cycles", s,
                    if (s == Severity.WARN) "ظرفیت باتری احتمالاً افت کرده؛ تعویض باتری را در نظر بگیرید." else null
                )
            }
        }
        return out
    }

    // ---------- Storage ----------
    private fun storage(ctx: Context): List<Finding> {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.totalBytes
        val free = st.availableBytes
        val pct = if (total > 0) free * 100 / total else 0
        val sev = when {
            pct < 7 -> Severity.BAD
            pct < 15 -> Severity.WARN
            else -> Severity.OK
        }
        return listOf(
            Finding(
                "حافظه داخلی",
                "${Formatter.formatFileSize(ctx, free)} آزاد از ${Formatter.formatFileSize(ctx, total)} ($pct%)",
                sev,
                if (sev != Severity.OK) "فایل‌های حجیم، ویدیوهای تکراری و برنامه‌های بلااستفاده را پاک کنید (دکمه «تنظیمات ذخیره‌سازی»). حافظه کم گوشی را کند می‌کند." else null
            )
        )
    }

    // ---------- Memory ----------
    private fun memory(ctx: Context): List<Finding> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val pct = if (mi.totalMem > 0) mi.availMem * 100 / mi.totalMem else 0
        val sev = when {
            mi.lowMemory -> Severity.BAD
            pct < 12 -> Severity.WARN
            else -> Severity.OK
        }
        return listOf(
            Finding(
                "حافظه رم",
                "${Formatter.formatFileSize(ctx, mi.availMem)} آزاد از ${Formatter.formatFileSize(ctx, mi.totalMem)}",
                sev,
                if (sev != Severity.OK) "برنامه‌های پس‌زمینه را ببندید یا گوشی را ریستارت کنید." else null
            )
        )
    }

    // ---------- Thermal ----------
    private fun thermal(ctx: Context): List<Finding> {
        if (Build.VERSION.SDK_INT < 29) return emptyList()
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val status = pm.currentThermalStatus
        val (txt, sev) = when (status) {
            0 -> "عادی" to Severity.OK
            1 -> "کمی گرم" to Severity.OK
            2 -> "گرم (عملکرد ممکن است محدود شود)" to Severity.WARN
            else -> "خیلی داغ (سیستم در حال محدودکردن پردازنده است)" to Severity.BAD
        }
        return listOf(
            Finding(
                "دمای پردازنده/دستگاه", txt, sev,
                if (sev != Severity.OK) "برنامه‌های سنگین را ببندید و گوشی را خنک کنید." else null
            )
        )
    }

    // ---------- CPU ----------
    private fun cpu(ctx: Context): List<Finding> {
        val cores = Runtime.getRuntime().availableProcessors()
        val soc = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE
        val out = mutableListOf<Finding>()
        out += Finding("پردازنده", "$soc | $cores هسته | ${Build.SUPPORTED_ABIS.firstOrNull() ?: "?"}", Severity.OK)

        try {
            val load1 = File("/proc/loadavg").readText().trim().split(" ")[0].toDouble()
            val sev = if (load1 > cores * 1.5) Severity.WARN else Severity.OK
            out += Finding(
                "بار پردازنده", "میانگین ۱ دقیقه: $load1", sev,
                if (sev != Severity.OK) "برنامه‌ای در پس‌زمینه زیاد کار می‌کند؛ از تنظیمات > باتری ببینید کدام برنامه است." else null
            )
        } catch (_: Exception) {
            // Some Android versions block /proc/loadavg for apps; silently skip.
        }
        return out
    }

    // ---------- Security / system ----------
    private fun security(ctx: Context): List<Finding> {
        val out = mutableListOf<Finding>()

        try {
            val patch = LocalDate.parse(Build.VERSION.SECURITY_PATCH)
            val months = ChronoUnit.MONTHS.between(patch, LocalDate.now())
            val sev = if (months > 12) Severity.WARN else Severity.OK
            out += Finding(
                "وصله امنیتی", "${Build.VERSION.SECURITY_PATCH} ($months ماه پیش)", sev,
                if (sev != Severity.OK) "از تنظیمات > به‌روزرسانی سیستم، آپدیت جدید را بررسی کنید." else null
            )
        } catch (_: Exception) {
            out += Finding("وصله امنیتی", "قابل خواندن نیست", Severity.WARN)
        }

        val adb = Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        out += Finding(
            "اشکال‌زدایی USB",
            if (adb) "روشن است" else "خاموش است",
            if (adb) Severity.WARN else Severity.OK,
            if (adb) "اگر برنامه‌نویس نیستید، آن را در گزینه‌های توسعه‌دهنده خاموش کنید." else null
        )

        return out
    }

    // ---------- Uptime ----------
    private fun uptime(ctx: Context): List<Finding> {
        val days = SystemClock.elapsedRealtime() / 86_400_000L
        val sev = if (days >= 14) Severity.WARN else Severity.OK
        return listOf(
            Finding(
                "مدت روشن بودن بدون ریستارت", "$days روز", sev,
                if (sev != Severity.OK) "یک بار گوشی را ریستارت کنید؛ بسیاری از کندی‌ها و باگ‌های موقتی برطرف می‌شود." else null
            )
        )
    }
}
